<?php
namespace {$module}\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class {$module}Controller extends AbstractActionController
{
	public function indexAction()
	{
	}
}