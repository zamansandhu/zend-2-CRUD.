<?php
return array (
  'Building\\Module' => '/var/www/html/zend-2-CRUD/module/Building/Module.php',
  'Codegenerator\\Module' => '/var/www/html/zend-2-CRUD/module/Codegenerator/Module.php',
);